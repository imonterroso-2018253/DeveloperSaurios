import React from 'react'
//import '../CSS/HomePage.css'
import logo from '../assets/logo.png';

export const HomePage = () => {
  return (
    <>
      <div className='contianer'>
        <div className="portfolio-logo">
          <div>

            <img src={logo} width="500" />

          </div>
        </div>
      </div>
    </>
  )
}
